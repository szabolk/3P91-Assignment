package GameComponents;

import UtilThings.EntityStats;
import UtilThings.EntityType;

public abstract class ArmyUnit extends Inhabitant implements IAttacker {
    protected int hp;
    protected int damage;
    protected int range;

    public ArmyUnit() {

    }

    @Override
    public int attack(IAttackable target) {

    }


    public int getDamage() {
        return 0;
    }


    public int getRange() {
        return 0;
    }


    public int getHP() {
        return 0;
    }
}
