package GameComponents;

import UtilThings.EntityStats;
import UtilThings.EntityType;

public abstract class Building implements IUpgradeable, IAttackable {
    protected EntityStats stats;
    protected int currentHp;
    protected boolean underConstruction;

    public Building(EntityStats stats) {

    }

    public abstract EntityType getEntityType();

    @Override
    public EntityStats getStats() {
        return null;
    }
    @Override
    public void setStats(EntityStats newStats) {

    }
}
