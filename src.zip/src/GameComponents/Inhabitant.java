package GameComponents;

import UtilThings.EntityStats;
import UtilThings.EntityType;

public abstract class Inhabitant implements IUpgradeable {
    protected EntityStats stats;

    Inhabitant (EntityStats stats) {
        this.stats = stats;
    }

    public abstract EntityType getEntityType();

    @Override
    public EntityStats getStats() {
        return this.stats;
    }

    @Override
    public void setStats(EntityStats newStats) {
        //grab the stat profile from EntityLevelData using the current level + 1 to get next stats details
        //will have to work out the logic if the unit should have fully restored hp or not
        //this.stats =
    }
}
