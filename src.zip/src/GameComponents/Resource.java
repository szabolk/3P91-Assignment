package GameComponents;

public class Resource {
    private int gold;
    private int iron;
    private int lumber;

    public Resource(int gold, int iron, int lumber) {

    }

    public int getGold() {
        return 0;
    }
    public void addGold(int amount) {

    }

    public int getIron() {
        return 0;
    }
    public void addIron(int amount) {

    }

    public int getLumber() {
        return 0;
    }

    public void addLumber(int amount) {

    }

    public void spend(int gold, int iron, int lumber) {

    }

    public boolean hasEnough(int gold, int iron, int lumber) {
        return true;
    }


}
