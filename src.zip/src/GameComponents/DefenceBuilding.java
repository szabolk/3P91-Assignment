package GameComponents;

public abstract class DefenceBuilding extends Building implements IAttacker {
    protected int damage;
    protected int range;

    public DefenceBuilding() {

    }

    @Override
    public int attack(IAttackable target) {
        return 0;
    }
}
