package GameComponents;

import UtilThings.*;

public class ResourceWorker extends Inhabitant {
    private EntityStats stats;
    private ResourceType productionType;


    ResourceWorker(ResourceType productionType) {
        //See worker class for an idea of how stats are going to work
        super(new EntityStats());
        this.productionType = productionType;
    }

    @Override
    public EntityType getEntityType() {
        return EntityType.RESOURCE_WORKER;
    }

    public ResourceType getResourceType() {
        return productionType;
    }
}
