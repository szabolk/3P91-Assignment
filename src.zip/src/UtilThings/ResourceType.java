package UtilThings;

public enum ResourceType {
    GOLD,
    IRON,
    WOOD,
}
