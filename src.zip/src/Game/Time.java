package Game;

public class Time {
    private int time;

    public Time() {

    }

    public int getTime() {
        return 0;
    }

    public void update() {

    }

    public boolean eventFinished(int time) {
        return true;
    }
}
