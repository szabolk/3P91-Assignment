package Game;

import GameComponents.DefenceBuilding;
import java.util.List;

public class Defences {
    private List<DefenceBuilding> defenceBuildings;
    private int defenceScore;

    public Defences() {

    }


    public void addDefenceBuilding(DefenceBuilding building) {

    }

    public void removeDefenceBuilding(DefenceBuilding building) {

    }

    public List<DefenceBuilding> getDefenceBuildings() {
        return null;
    }

    public int getDefenceScore() {
        return 0;
    }
}
