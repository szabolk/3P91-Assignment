package Game;

import GameComponents.ArmyUnit;
import java.util.List;

public class Army {
    private List<ArmyUnit> units;
    private int attackScore;

    public Army() {

    }

    public void addUnit(ArmyUnit unit) {

    }

    public void removeUnit(ArmyUnit unit){

    }

    public List<ArmyUnit> getUnits() {
        return null;
    }
    public int getAttackScore() {
        return 0;
    }
}
