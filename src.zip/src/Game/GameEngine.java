package Game;

import java.util.List;

public class GameEngine {
    private Time gameTime;
    private List<Village> villages;


    public GameEngine() {

    }

    public void playGame() {

    }

    public Village generateVillage(Village playerVillage) {
        return null;
    }

    public SimulationResult simulateAttack(Army attacker, Defences defender) {
        return null;
    }

    public void increaseTime() {

    }

    public void setGuardTime(Village village) {

    }

}
