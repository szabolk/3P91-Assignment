package UtilThings;

public enum EntityType {
    SOLDIER,
    ARCHER,
    KNIGHT,
    CATAPULT,
    RESOURCE_WORKER,
    WORKER,
    GOLD_MINE,
    IRON_MINE,
    LUMBER_MILL,
    FARM,
    VILLAGE_HALL,
    ARCHER_TOWER,
    CANNON
}
