package UtilThings;

//Here just in case for some reason we might swap to resources using an enum type
public enum ResourceType {
    GOLD,
    IRON,
    WOOD,
}
