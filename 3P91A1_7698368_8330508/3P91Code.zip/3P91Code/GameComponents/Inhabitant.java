package GameComponents;

import UtilThings.EntityStats;
import UtilThings.EntityType;

//This might not be necessary since it doesnt add anything.
public abstract class Inhabitant extends Entity {
    Inhabitant (EntityStats stats) {
        super(stats);
    }
}
