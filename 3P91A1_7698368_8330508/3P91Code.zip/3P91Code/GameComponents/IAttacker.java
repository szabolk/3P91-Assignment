package GameComponents;

public interface IAttacker {
    public int attack(IAttackable target);
}
