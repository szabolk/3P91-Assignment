package Game;

import GameComponents.DefenceBuilding;
import java.util.List;

//Defence buildings for each village
public class Defences {
    private List<DefenceBuilding> defenceBuildings;
    private int defenceScore;

    public Defences() {

    }


    public void addDefenceBuilding(DefenceBuilding building) {

    }

    public void removeDefenceBuilding(DefenceBuilding building) {

    }

    public List<DefenceBuilding> getDefenceBuildings() {
        return null;
    }
    /**
     * Gets the defence score
     * @return int - gives back a value used by the GameEngine in the attack simulations
     */
    public int getDefenceScore() {
        return 0;
    }
}
