package Game;

//Information about a player
public class Player {
    private int playerID;
    private Village village;

    public Player(int id) {

    }

    public int getPlayerID() {
        return 0;
    }

    public Village getVillage() {
        return null;
    }

    public void setVillage(Village village) {

    }

    public Village exploreAttack() {
        return null;
    }

}
